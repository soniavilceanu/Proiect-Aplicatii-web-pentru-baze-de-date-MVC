# Proiect-Aplicatii-web-pentru-baze-de-date-MVC


Se poate loga cu username: guest, password: 1234 (nu poate da update, delete sau add)

sau cu username: admin, password: 1234 (are drepturi complete)

http://localhost:8080/showLogInForm - pentru logare in aplicatie

http://localhost:8080/index - pentru a sari peste logare
