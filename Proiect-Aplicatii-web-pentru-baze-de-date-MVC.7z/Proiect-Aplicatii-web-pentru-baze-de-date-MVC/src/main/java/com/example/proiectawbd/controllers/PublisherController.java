package com.example.proiectawbd.controllers;

import org.springframework.stereotype.Controller;

@Controller
public class PublisherController {
}
