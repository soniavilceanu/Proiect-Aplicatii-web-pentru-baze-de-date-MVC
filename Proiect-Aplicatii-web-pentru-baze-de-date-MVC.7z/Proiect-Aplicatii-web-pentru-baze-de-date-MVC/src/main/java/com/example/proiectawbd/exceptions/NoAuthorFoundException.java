package com.example.proiectawbd.exceptions;

public class NoAuthorFoundException extends RuntimeException{

    public  NoAuthorFoundException(String message) {
        super(message);
    }
}
