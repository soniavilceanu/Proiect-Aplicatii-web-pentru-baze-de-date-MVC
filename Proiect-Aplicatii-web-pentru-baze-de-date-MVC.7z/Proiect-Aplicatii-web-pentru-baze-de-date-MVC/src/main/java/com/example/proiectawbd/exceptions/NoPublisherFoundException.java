package com.example.proiectawbd.exceptions;

public class NoPublisherFoundException extends RuntimeException{

    public  NoPublisherFoundException(String message) {
        super(message);
    }
}
