package com.example.proiectawbd;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProiectawbdApplication {

    public static void main(String[] args) {
        SpringApplication.run(ProiectawbdApplication.class, args);
    }

}
