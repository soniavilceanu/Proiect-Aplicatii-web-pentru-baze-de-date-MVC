package com.example.proiectawbd.repositories;


import com.example.proiectawbd.domain.BookDetails;
import org.springframework.data.jpa.repository.JpaRepository;

public interface BookDetailsRepository extends JpaRepository<BookDetails, Integer> {


}

