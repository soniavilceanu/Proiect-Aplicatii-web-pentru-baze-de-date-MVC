package com.example.proiectawbd.exceptions;

public class NoBookDetailsFoundException extends RuntimeException{

    public  NoBookDetailsFoundException(String message) {
        super(message);
    }
}
