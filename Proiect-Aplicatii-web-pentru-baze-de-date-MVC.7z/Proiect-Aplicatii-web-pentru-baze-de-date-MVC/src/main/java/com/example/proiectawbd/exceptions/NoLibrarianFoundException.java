package com.example.proiectawbd.exceptions;

public class NoLibrarianFoundException extends RuntimeException{

    public  NoLibrarianFoundException(String message) {
        super(message);
    }
}
