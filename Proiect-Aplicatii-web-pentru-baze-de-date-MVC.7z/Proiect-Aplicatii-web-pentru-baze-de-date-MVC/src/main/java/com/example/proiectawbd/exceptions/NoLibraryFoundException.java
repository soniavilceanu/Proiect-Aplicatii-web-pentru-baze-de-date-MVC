package com.example.proiectawbd.exceptions;

public class NoLibraryFoundException extends RuntimeException{

    public  NoLibraryFoundException(String message) {
        super(message);
    }
}
