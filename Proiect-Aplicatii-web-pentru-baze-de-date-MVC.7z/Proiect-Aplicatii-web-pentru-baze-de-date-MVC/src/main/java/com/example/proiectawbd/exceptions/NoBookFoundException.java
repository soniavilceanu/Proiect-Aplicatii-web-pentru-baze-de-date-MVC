package com.example.proiectawbd.exceptions;


public class NoBookFoundException extends RuntimeException{

    public  NoBookFoundException(String message) {
        super(message);
    }
}

